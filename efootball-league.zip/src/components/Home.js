import React from "react";

function Home() {
  return (
    <div className="home">
      <h1>Welcome to Football Tournament Manager</h1>
      <p>Create and manage your tournaments easily!</p>
    </div>
  );
}

export default Home;
